﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceCreamProject
{
    class Program
    {
        static List<string> DeliveryPointList = new List<string>(), PickUPickUpPointsointList = new List<string>(); //Delviery point:DeliveryPoints //PickUPickUpPointsoints:PickUpPoints
        static void Main(string[] args)
        {
            try
            {
                DeliveryPointList = new List<string>();
                PickUPickUpPointsointList = new List<string>();
                Console.WriteLine(" Ice Cream company Factory ");
                Console.Write("Enter No of Delivery Points!!!: ");
                var DeliveryPointsCount = 0;
                if (!int.TryParse(Console.ReadLine().Trim(), out DeliveryPointsCount) || DeliveryPointsCount <= 0)
                {
                    Console.WriteLine("Invalid Input");
                    Console.ReadLine();
                    return;

                }
                do
                {
                    Console.Write(string.Format("DeliveryPoints{0}:", DeliveryPointList.Count + 1));
                    var DeliveryPoints = Console.ReadLine();
                    if (validateDeliveryPoint(DeliveryPoints.Trim())) DeliveryPointList.Add(DeliveryPoints);
                }
                while (DeliveryPointList.Count < DeliveryPointsCount);

                Console.Write("Enter No of Pickup Points: ");

                var PickUpPointsCount = 0;
                if (!int.TryParse(Console.ReadLine().Trim(), out PickUpPointsCount) || PickUpPointsCount <= 0)
                {
                    Console.WriteLine("Invalid Input");
                    Console.ReadLine();
                    return;
                }
                do
                {
                    Console.Write(string.Format("PickUpPoints{0}:", PickUPickUpPointsointList.Count + 1));
                    var PickUpPoints = Console.ReadLine();
                    if (validatePickuPickUpPointsoint(PickUpPoints.Trim())) PickUPickUpPointsointList.Add(PickUpPoints);
                }
                while (PickUPickUpPointsointList.Count < PickUpPointsCount);

                findRoute();
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Invalid Input");
                Console.ReadLine();
            }
        }

        static void findRoute()
        {
            string selectedDeliveryPoints = "", selectedDeliveryPointsName = "", selecteDeliveryPointsP = "", selecteDeliveryPointsPName = "";
            findlargeArrayDeliveryPoint(out selectedDeliveryPoints, out selectedDeliveryPointsName);
            findlargeArrayPickuPickUpPointsoint(out selecteDeliveryPointsP, out selecteDeliveryPointsPName);
            Console.WriteLine(" ");
            Console.WriteLine("Output :");
            Console.WriteLine("--------");
            Console.WriteLine(string.Format("Route : {0}-{1}", selectedDeliveryPointsName, selecteDeliveryPointsPName));
            Console.WriteLine("Start from Factory @ : 9 AM");
            Console.WriteLine("Delivery Point: " + selectedDeliveryPointsName);
            DateTime deliveryTime = new DateTime(2021, 3, 9, 7, 0, 0).AddHours(Convert.ToInt32(selectedDeliveryPoints.Split(',')[1].Trim())); 
            Console.WriteLine("Delivery Time: " + deliveryTime.ToString("h tt"));
            Console.WriteLine("Pickup Point: " + selecteDeliveryPointsPName);

            DateTime pickupTime = deliveryTime.AddHours(Convert.ToInt32(selecteDeliveryPointsP.Split(',')[0].Trim()));
            Console.WriteLine("Pickup Time: " + pickupTime.ToString("h tt"));
            Console.WriteLine("Time in Truck: " + selecteDeliveryPointsP.Split(',')[0].Trim() + " hours");

        }

        static bool validateDeliveryPoint(string DeliveryPoints)
        {
            var DeliveryPointsArray = DeliveryPoints.Split(',');
            if (DeliveryPointsArray.Length == 2)
            {
                if (IsNumeric(DeliveryPointsArray[0].Trim()) && IsNumeric(DeliveryPointsArray[1].Trim()))
                {

                    return true;
                }
            }

            Console.WriteLine("Invalid DeliveryPoints input!");
            return false;
        }

        static bool validatePickuPickUpPointsoint(string PickUpPoints)
        {
            var PickUpPointsArray = PickUpPoints.Split(',');
            if (PickUpPointsArray.Length == 2)
            {
                if (IsNumeric(PickUpPointsArray[0].Trim()) && IsNumeric(PickUpPointsArray[1].Trim()))
                    return true;
            }

            Console.WriteLine("Invalid PickUpPoints input!");
            return false;
        }

        static bool IsNumeric(string value)
        {
            foreach (char c in value)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }

            return true;
        }

        static void findlargeArrayDeliveryPoint(out string selectedDeliveryPoints, out string selectedDeliveryPointsName)
        {
            int i = 1;
            selectedDeliveryPoints = "";
            selectedDeliveryPointsName = "";
            foreach (var item in DeliveryPointList)
            {
                if (i == 1)
                {
                    selectedDeliveryPoints = item;
                    selectedDeliveryPointsName = "DeliveryPoints" + i;
                }
                else if (Convert.ToInt32(selectedDeliveryPoints.Split(',')[1].Trim()) < Convert.ToInt32(item.Split(',')[1].Trim()))
                {
                    selectedDeliveryPoints = item;
                    selectedDeliveryPointsName = "DeliveryPoints" + i;
                }
                i++;
            }
        }

        static void findlargeArrayPickuPickUpPointsoint(out string selecteDeliveryPointsP, out string selecteDeliveryPointsPName)
        {
            int i = 1;
            selecteDeliveryPointsP = "";
            selecteDeliveryPointsPName = "";
            foreach (var item in PickUPickUpPointsointList)
            {
                if (i == 1)
                {
                    selecteDeliveryPointsP = item;
                    selecteDeliveryPointsPName = "PickUpPoints" + i;
                }
                else
                {
                    if (Convert.ToInt32(item.Split(',')[0].Trim()) > Convert.ToInt32(selecteDeliveryPointsP.Split(',')[0].Trim()))
                    {
                        selecteDeliveryPointsP = item;
                        selecteDeliveryPointsPName = "PickUpPoints" + i;
                    }
                    else if (Convert.ToInt32(item.Split(',')[0].Trim()) >= Convert.ToInt32(selecteDeliveryPointsP.Split(',')[0].Trim()) && Convert.ToInt32(item.Split(',')[1].Trim()) > Convert.ToInt32(selecteDeliveryPointsP.Split(',')[1].Trim()))
                    {
                        selecteDeliveryPointsP = item;
                        selecteDeliveryPointsPName = "PickUpPoints" + i;
                    }
                }
                i++;

            }
        }
    }
}
